#000000
//show:color(background)
#353535
//show:color(menu)
#ffffff
//show:color(text)
